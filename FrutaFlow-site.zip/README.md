# FrutaFlow
Protótipo de interface de uma plataforma de IA para animar fotos e adicionar falas.

## Uso
Abra `index.html` no navegador.

Observação: esta versão é um protótipo frontend. O botão de geração simula o fluxo; para geração real é necessário conectar um backend/API de vídeo e voz.
